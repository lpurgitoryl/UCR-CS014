#include "Playlist.h"

   string PlaylistNode::GetID(){
        return this->uniqueID;

    }

    string PlaylistNode::GetSongName(){
        return this->songName;
    }

    string PlaylistNode::GetArtistName(){
        return this->artistName;
    }

    int PlaylistNode::GetSongLength(){
        return this->songLength;
    }

    PlaylistNode *  PlaylistNode::GetNext(){
      return this->nextNodePtr;

    }

    void PlaylistNode::PrintPlaylistNode() {
        cout << "Unique ID: " << uniqueID << endl;
        cout << "Song Name: " << songName << endl;
        cout << "Artist Name: " << artistName << endl;
        cout << "Song Length (in seconds): " << songLength << endl;
    }

    void PlaylistNode::SetNext(PlaylistNode * node){
        this->nextNodePtr = node;
    }

    void PlaylistNode::InsertAfter(PlaylistNode* node){
        PlaylistNode* tmp = this->nextNodePtr;
        this->nextNodePtr = node;
        node->nextNodePtr = tmp;
    }

    




    // void Playlist::addSong(){
    //     cout << "ADD SONG" << endl;

    //     cout << "Enter song's unique ID:" << endl;
    //     string id;
    //     cin >> id;

    //     cout << "Enter song's name:" << endl;
    //     string songN;
    //     cin.ignore(1);
    //     getline(cin, songN);

    //     cout << "Enter artist's name:" << endl;
    //     string artist;
    //     getline(cin, artist);

    //     cout << "Enter song's length (in seconds):" ;
    //     int time;
    //    // cin.ignore(1);
    //     cin >> time;
    //     cout << endl;

    //     Playlist* tmp = new Playlist(id, songN, artist, time);

    //     if(!head){
    //         this->head = tmp;
    //         this->tail = head;
    //     }
    //     else{
    //         tail->SetNext(tmp);
    //         tail = tmp;
    //     }
        
    //     return;
    // }

    //  void Playlist::displayPlaylist(){
    //      PlaylistNode* curr = nullptr;
    //      int counter = 1;
        
    //     cout << this->PlaylistName << " - OUTPUT FULL PLAYLIST" << endl;
    //     if(!head){
    //         cout << "Playlist is empty" << endl;
    //         return;
    //     }
        
    //     for(curr = head; curr != nullptr; curr = curr->GetNext()){
    //         cout << counter << "." << endl;
    //         curr->PrintPlaylistNode();
    //         cout << endl;
    //         counter++;
    //     }
    //     return;
    //  }
    //  void Playlist::postion(){
    //      cout << "CHANGE POSITION OF SONG" << endl;
    //      cout << "Enter song's current postion" << endl;
    //      int currPosition;
    //      cin >> currPosition;
    //      cout << endl;
        
    //     cout << "Enter new position for song" << endl;
    //     int newPos;
    //     cin >> newPos;
    //     cout << endl;

    //     int counter = 0;
    //       for(PlaylistNode* curr = head; curr != nullptr; curr = curr->GetNext() ){
    //         counter++;
    //      }
    //      if(counter == 2 ){//two nodes
    //          PlaylistNode* tmp = tail;
    //          tail = head;
    //          head = tmp;
    //          tail->setNull();
    //          head->setPtr(tail);
    //          return;
    //      }
    //     else if( (currPosition == 1)  ){//head to tail
    //         if( (newPos >= counter) ){ 
    //         PlaylistNode* tmp = head;
    //         head = head->GetNext();
    //         tmp->setNull();
    //         tail->SetNext(tmp);
    //         tail = tmp;
           
    //         return;
    //         }
            
    //     }

        
    //     PlaylistNode* tmp = nullptr;
    //     int indexC = 0;
    //     int indexN = 0;
    //     for(PlaylistNode* curr = head; curr != nullptr; curr = curr->GetNext() ){
    //         indexC++;

    //         for(PlaylistNode* next = head; next != nullptr; next = curr->GetNext() ){
    //             indexN++;

    //             if( (currPosition == 1) && (newPos < counter ) && (newPos == indexN + 1) ) { //head to any node but tail
    //                 tmp = head;
    //                 head = head->GetNext();
    //                //q
    //                 tmp->setNull();
        
    //                 next->InsertAfter(tmp);
    //                 return;
    //             }

    //            else if( (newPos == indexN + 1) && (currPosition == indexC +1) && (currPosition != counter) ) { //any node but tail
    //                 tmp = curr->GetNext();
    //                 curr->InsertAfter(tmp->GetNext() );
    //                 next->InsertAfter(tmp);
    //                 return;

    //             }
    //             else if((currPosition == indexC +1) && (counter = currPosition ) && (tail != curr)  ){
                   
    //                 if(newPos <= 1){
    //                 tmp = tail;
    //                 curr->setNull();
    //                 tail = next;
    //                     tmp->SetNext(head);
    //                     head = tmp;
    //                 }
    //                 else if( (newPos == indexN + 1) && (newPos >= counter) ){
    //                 curr->setNull();
    //                 next->InsertAfter(tail);
    //                 tail = curr;

    //                 return;
                    
    //                 }

    //             }
    //         }
    //      }
    //  }
    // void Playlist::removeSong(){
    //     cout << "REMOVE SONG" << endl;
    //     cout << "Enter song's unique ID:" << endl;
    //     string id;
    //     cin >> id;

    //     if(!head){
    //         cout << "No songs to remove" << endl;
    //         return;
    //     }
    //     else if(head == tail){
    //         if( id == head->GetID() ){
    //            cout << "\"" << head->GetSongName() << "\"" << 
    //            " removed." << endl;
    //             delete head;
    //             head = nullptr;
    //             tail = nullptr;
    //              cout << "first song removed " << id <<  endl;
    //             return;
    //         }
    //         cout << "There is no song with the ID of " << id <<  endl;
    //         return;
    //     }
    //     PlaylistNode* curr = head;
    //     PlaylistNode* next = head;

        
    //     for(curr = head; curr != tail; curr = curr->GetNext() ){
    //        next = next->GetNext();
    //         if(next == tail){
    //             if(id == next->GetID() ){
    //                 cout << "\"" << next->GetSongName() << "\"" << 
    //            " removed." << endl;
    //             delete next;
    //             curr->setNull();
    //             tail = curr;
    //             return;
    //             }
    //             cout << "There is no song with the ID of " << id << endl;
    //             return;
    //         }

    //         else if(id == next->GetID() ){
    //             cout << "\"" << next->GetSongName() << "\"" << 
    //            " removed." << endl;
    //            curr->setPtr(next->GetNext());
    //            delete next;

    //         }
    //     }
       
    // }

    // void Playlist::songsByArtist(){
        
    //     cout << "OUTPUT SONGS BY SPECIFIC ARTIST" << endl << "Enter artist's name:" << endl;
    //     string aName;
    //     cin.ignore();
    //     getline(cin, aName);
    //     cout << endl;
        
    //     if(!head){
    //         cout << "There are no songs in the playlist" << endl;
    //     }
    //     int counter = 1;
    //     for(PlaylistNode* curr = head; curr != nullptr; curr = curr->GetNext() ){
    //         if(aName == curr->GetArtistName() ){
    //             cout << counter << "." << endl;
    //             curr->PrintPlaylistNode();
    //             cout << endl;
    //         }

    //         counter++;
    //     }
    // }

    
    //  void Playlist::totalTime(){
    //       PlaylistNode* curr = nullptr;
    //      int time = 0;
        
    //     for(curr = head; curr != nullptr; curr = curr->GetNext()){
    //         time += curr->GetSongLength();
    //     }
    //     cout <<"OUTPUT TOTAL TIME OF PLAYLIST (IN SECONDS)" << endl;
    //     cout << "Total time: " << time << " seconds" << endl;
    //  }


