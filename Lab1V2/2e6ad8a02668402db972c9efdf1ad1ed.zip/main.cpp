#include "Playlist.h"
#include <iostream>
#include <string>

using namespace std;


void PrintMenu( string name);
void displayPlaylist(PlaylistNode* &head, PlaylistNode* &tail);
void addSong(PlaylistNode* &head, PlaylistNode* &tail);
void totalTime(PlaylistNode* head, PlaylistNode* tail);

        // void removeSong(); //finished but check for errors
        // void postion();
        // void songsByArtist();
        // void totalTime(); // looks like it works 
        // void displayPlaylist();//done

int main() {
    string pName;
    char letter;
    
    cout << "Enter playlist's title:" << endl;
    getline(cin,pName);

    cout << endl;

    PrintMenu(pName);

    cout << endl;
    cout << "Choose an option:" ;
    cin >> letter;
    cout << endl;
   
   PlaylistNode* head = new PlaylistNode();
   PlaylistNode* tail = new PlaylistNode();
//   PlaylistNode* head = nullptr;
//    PlaylistNode* tail = nullptr;

while( letter != 'q'){

    if(letter == 'a'){
        
        addSong(head, tail);
        PrintMenu(pName);
    }
    else if(letter == 'd'){
        // removeSong(head, tail);
        PrintMenu(pName);
    }
    else if(letter == 'c'){
        // postion(head, tail);
        PrintMenu(pName);
    }
    else if(letter == 's'){
        // songsByArtist(head, tail);
        PrintMenu(pName);
    }
    else if(letter == 't'){
        totalTime(head, tail);
        PrintMenu(pName);
    }
    else if(letter == 'o'){
        cout << pName << "- OUTPUT FULL PLAYLIST" << endl;
        displayPlaylist(head, tail);
        cout << endl;
        PrintMenu(pName);
    }
     
    cout << endl;
    cout << "Choose an option:" ;
    cin >> letter;
   // cout << endl;
}

    




    return 0;
}

void PrintMenu( string name){
    
    cout << name << " PLAYLIST MENU" << endl;

       cout <<"a - Add song" << endl 
       << "d - Remove song" << endl 
       << "c - Change position of song" << endl 
       << "s - Output songs by specific artist" << endl 
       << "t - Output total time of playlist (in seconds)"<< endl
       << "o - Output full playlist" << endl << "q - Quit" << endl ;
}

       
void addSong(PlaylistNode* &head, PlaylistNode* &tail){
    cout << "ADD SONG" << endl;

    cout << "Enter song's unique ID:" << endl;
    string id;
    cin >> id;

    cout << "Enter song's name:" << endl;
    string songN;
    cin.ignore(1);
    getline(cin, songN);

    cout << "Enter artist's name:" << endl;
    string artist;
    getline(cin, artist);

    cout << "Enter song's length (in seconds):" ;
    int time;
    // cin.ignore(1);
    cin >> time;
    cout << endl;

   PlaylistNode* tmp =  new PlaylistNode( id,  songN, artist, time);

    if( ( head->GetSongLength() == 0 ) && ( tail->GetSongLength() == 0) ){// takes care of no list case
        delete head;
        delete tail;

        // head = new PlaylistNode(id,  songN, artist, time);
        head = tmp;

        tail = head;
        cout << " head and tail" << endl;

        return;
    }
   
    else{
        tail->SetNext(tmp);
        tail = tmp;
        cout << "added to tail" << endl;

    }
 
    return;
}
        
void displayPlaylist(PlaylistNode* &head, PlaylistNode* &tail){
    if( ( head->GetSongLength() == 0 ) && ( tail->GetSongLength() == 0) ){
        cout << "Playlist is empty" << endl;
        return;
    }
    int counter = 1;

    for(PlaylistNode* curr = head; curr != nullptr; curr = curr->GetNext() ){
        cout << counter << "." << endl;
        curr->PrintPlaylistNode();
        counter++;
    }

    return;
}

void totalTime(PlaylistNode* head, PlaylistNode* tail){
    if( ( head->GetSongLength() == 0 ) && ( tail->GetSongLength() == 0) ){
        cout << "Playlist is empty" << endl;
        return;
    }
}
